
Object.defineProperty(exports, "__esModule", { value: true });

const {
  Decimal,
  objectEnumValues,
  makeStrictEnum,
  Public,
  getRuntime,
  skip
} = require('@prisma/client/runtime/index-browser.js')


const Prisma = {}

exports.Prisma = Prisma
exports.$Enums = {}

/**
 * Prisma Client JS version: 5.22.0
 * Query Engine version: 605197351a3c8bdd595af2d2a9bc3025bca48ea2
 */
Prisma.prismaVersion = {
  client: "5.22.0",
  engine: "605197351a3c8bdd595af2d2a9bc3025bca48ea2"
}

Prisma.PrismaClientKnownRequestError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientKnownRequestError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)};
Prisma.PrismaClientUnknownRequestError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientUnknownRequestError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientRustPanicError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientRustPanicError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientInitializationError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientInitializationError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientValidationError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientValidationError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.NotFoundError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`NotFoundError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.Decimal = Decimal

/**
 * Re-export of sql-template-tag
 */
Prisma.sql = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`sqltag is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.empty = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`empty is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.join = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`join is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.raw = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`raw is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.validator = Public.validator

/**
* Extensions
*/
Prisma.getExtensionContext = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`Extensions.getExtensionContext is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.defineExtension = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`Extensions.defineExtension is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}

/**
 * Shorthand utilities for JSON filtering
 */
Prisma.DbNull = objectEnumValues.instances.DbNull
Prisma.JsonNull = objectEnumValues.instances.JsonNull
Prisma.AnyNull = objectEnumValues.instances.AnyNull

Prisma.NullTypes = {
  DbNull: objectEnumValues.classes.DbNull,
  JsonNull: objectEnumValues.classes.JsonNull,
  AnyNull: objectEnumValues.classes.AnyNull
}



/**
 * Enums
 */

exports.Prisma.TransactionIsolationLevel = makeStrictEnum({
  ReadUncommitted: 'ReadUncommitted',
  ReadCommitted: 'ReadCommitted',
  RepeatableRead: 'RepeatableRead',
  Serializable: 'Serializable'
});

exports.Prisma.ApplicationLogScalarFieldEnum = {
  id: 'id',
  level: 'level',
  message: 'message',
  meta: 'meta',
  timestamp: 'timestamp'
};

exports.Prisma.AuditLogScalarFieldEnum = {
  id: 'id',
  table_name: 'table_name',
  record_id: 'record_id',
  action: 'action',
  previous_data: 'previous_data',
  new_data: 'new_data',
  changed_by: 'changed_by',
  timestamp: 'timestamp'
};

exports.Prisma.CompanyScalarFieldEnum = {
  id: 'id',
  company_name: 'company_name',
  company_short_name: 'company_short_name',
  company_code: 'company_code',
  registration_number: 'registration_number',
  tax_id: 'tax_id',
  address: 'address',
  city: 'city',
  state: 'state',
  country: 'country',
  postal_code: 'postal_code',
  phone: 'phone',
  email: 'email',
  website: 'website',
  is_seller: 'is_seller',
  is_verified: 'is_verified',
  seller_id: 'seller_id',
  industry: 'industry',
  number_of_employees: 'number_of_employees',
  annual_revenue: 'annual_revenue',
  description: 'description',
  is_active: 'is_active',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip'
};

exports.Prisma.CompanyAdditionalInfoScalarFieldEnum = {
  id: 'id',
  company_id: 'company_id',
  short_description: 'short_description',
  facebook_link: 'facebook_link',
  twitter_link: 'twitter_link',
  instagram_link: 'instagram_link',
  linkedin_link: 'linkedin_link',
  youtube_link: 'youtube_link',
  whatsapp_number: 'whatsapp_number',
  google_map_link: 'google_map_link',
  vision: 'vision',
  mission: 'mission',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip'
};

exports.Prisma.UserScalarFieldEnum = {
  id: 'id',
  fullname: 'fullname',
  username: 'username',
  email: 'email',
  password: 'password',
  address: 'address',
  phone: 'phone',
  is_active: 'is_active',
  is_admin: 'is_admin',
  is_password_reset: 'is_password_reset',
  user_type: 'user_type',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip',
  company_id: 'company_id'
};

exports.Prisma.RefreshTokenScalarFieldEnum = {
  id: 'id',
  token: 'token',
  userId: 'userId',
  expiresAt: 'expiresAt',
  createdAt: 'createdAt',
  isRevoked: 'isRevoked'
};

exports.Prisma.SecurityRuleScalarFieldEnum = {
  id: 'id',
  name: 'name',
  description: 'description',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip',
  company_id: 'company_id'
};

exports.Prisma.SecurityRuleWiseMenuPermissionScalarFieldEnum = {
  id: 'id',
  menu_id: 'menu_id',
  can_view: 'can_view',
  can_create: 'can_create',
  can_update: 'can_update',
  can_delete: 'can_delete',
  can_report: 'can_report',
  rule_id: 'rule_id',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip',
  company_id: 'company_id'
};

exports.Prisma.SecurityGroupScalarFieldEnum = {
  id: 'id',
  name: 'name',
  description: 'description',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip',
  company_id: 'company_id'
};

exports.Prisma.SecurityGroupRuleScalarFieldEnum = {
  id: 'id',
  group_id: 'group_id',
  rule_id: 'rule_id',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip',
  company_id: 'company_id'
};

exports.Prisma.UserGroupScalarFieldEnum = {
  id: 'id',
  user_id: 'user_id',
  group_id: 'group_id',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip',
  company_id: 'company_id'
};

exports.Prisma.MenuScalarFieldEnum = {
  id: 'id',
  title: 'title',
  url: 'url',
  icon: 'icon',
  icon_library: 'icon_library',
  parent_id: 'parent_id',
  sequence_no: 'sequence_no',
  is_active: 'is_active',
  can_view: 'can_view',
  can_create: 'can_create',
  can_update: 'can_update',
  can_delete: 'can_delete',
  can_report: 'can_report'
};

exports.Prisma.ProductScalarFieldEnum = {
  id: 'id',
  name: 'name',
  slug: 'slug',
  description: 'description',
  price: 'price',
  priceRange: 'priceRange',
  compareAtPrice: 'compareAtPrice',
  images: 'images',
  thumbnail: 'thumbnail',
  hasVariants: 'hasVariants',
  stock: 'stock',
  tags: 'tags',
  rating: 'rating',
  reviewCount: 'reviewCount',
  status: 'status',
  isFeatured: 'isFeatured',
  isNew: 'isNew',
  onSale: 'onSale',
  salePercentage: 'salePercentage',
  salePrice: 'salePrice',
  saleStartDate: 'saleStartDate',
  saleEndDate: 'saleEndDate',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip',
  company_id: 'company_id',
  categoryId: 'categoryId',
  subcategoryId: 'subcategoryId',
  brandId: 'brandId',
  sellerId: 'sellerId',
  specialOfferId: 'specialOfferId'
};

exports.Prisma.CategoryScalarFieldEnum = {
  id: 'id',
  name: 'name',
  slug: 'slug',
  image: 'image',
  icon: 'icon',
  featured: 'featured',
  productCount: 'productCount',
  is_active: 'is_active',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip',
  company_id: 'company_id'
};

exports.Prisma.SubcategoryScalarFieldEnum = {
  id: 'id',
  name: 'name',
  slug: 'slug',
  productCount: 'productCount',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip',
  company_id: 'company_id',
  categoryId: 'categoryId'
};

exports.Prisma.BrandScalarFieldEnum = {
  id: 'id',
  name: 'name',
  slug: 'slug',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip',
  company_id: 'company_id'
};

exports.Prisma.ProductAttributeScalarFieldEnum = {
  id: 'id',
  name: 'name',
  type: 'type',
  value: 'value',
  unit: 'unit',
  displayValue: 'displayValue',
  options: 'options',
  productId: 'productId'
};

exports.Prisma.ProductVariantScalarFieldEnum = {
  id: 'id',
  sku: 'sku',
  price: 'price',
  stock: 'stock',
  attributes: 'attributes',
  images: 'images',
  sequence_no: 'sequence_no',
  productId: 'productId'
};

exports.Prisma.SellerScalarFieldEnum = {
  id: 'id',
  name: 'name',
  slug: 'slug',
  email: 'email',
  phone: 'phone',
  logo: 'logo',
  rating: 'rating',
  reviewCount: 'reviewCount',
  verified: 'verified',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip',
  company_id: 'company_id'
};

exports.Prisma.ReviewScalarFieldEnum = {
  id: 'id',
  userId: 'userId',
  userName: 'userName',
  userAvatar: 'userAvatar',
  rating: 'rating',
  title: 'title',
  comment: 'comment',
  helpful: 'helpful',
  createdAt: 'createdAt',
  variantId: 'variantId',
  productId: 'productId'
};

exports.Prisma.CustomerScalarFieldEnum = {
  id: 'id',
  first_name: 'first_name',
  last_name: 'last_name',
  email: 'email',
  phone: 'phone',
  password: 'password',
  is_active: 'is_active',
  remember_token: 'remember_token',
  email_verified: 'email_verified',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip'
};

exports.Prisma.CustomerRefreshTokenScalarFieldEnum = {
  id: 'id',
  token: 'token',
  customerId: 'customerId',
  expiresAt: 'expiresAt',
  createdAt: 'createdAt',
  isRevoked: 'isRevoked'
};

exports.Prisma.OrderScalarFieldEnum = {
  id: 'id',
  orderNumber: 'orderNumber',
  userId: 'userId',
  status: 'status',
  totalAmount: 'totalAmount',
  shippingCost: 'shippingCost',
  tax: 'tax',
  discount: 'discount',
  finalAmount: 'finalAmount',
  shippingAddress: 'shippingAddress',
  billingAddress: 'billingAddress',
  paymentMethod: 'paymentMethod',
  paymentStatus: 'paymentStatus',
  trackingNumber: 'trackingNumber',
  trackingStatus: 'trackingStatus',
  customerId: 'customerId',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip',
  company_id: 'company_id',
  paymentGateway: 'paymentGateway',
  sslcommerzTransactionId: 'sslcommerzTransactionId',
  paypalOrderId: 'paypalOrderId',
  paymentMetadata: 'paymentMetadata',
  coupon_id: 'coupon_id',
  discount_amount: 'discount_amount'
};

exports.Prisma.OrderItemScalarFieldEnum = {
  id: 'id',
  orderId: 'orderId',
  productId: 'productId',
  variantId: 'variantId',
  quantity: 'quantity',
  unitPrice: 'unitPrice',
  totalPrice: 'totalPrice',
  productName: 'productName',
  variantAttributes: 'variantAttributes',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip',
  company_id: 'company_id'
};

exports.Prisma.StockMovementScalarFieldEnum = {
  id: 'id',
  productId: 'productId',
  variantId: 'variantId',
  quantity: 'quantity',
  type: 'type',
  reference: 'reference',
  notes: 'notes',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip',
  company_id: 'company_id'
};

exports.Prisma.UserSettingsScalarFieldEnum = {
  id: 'id',
  user_id: 'user_id',
  settings: 'settings',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip',
  company_id: 'company_id'
};

exports.Prisma.CustomerAddressScalarFieldEnum = {
  id: 'id',
  customerId: 'customerId',
  label: 'label',
  firstName: 'firstName',
  lastName: 'lastName',
  phone: 'phone',
  email: 'email',
  address: 'address',
  apartment: 'apartment',
  city: 'city',
  state: 'state',
  country: 'country',
  postalCode: 'postalCode',
  isDefault: 'isDefault',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip'
};

exports.Prisma.PendingOrderScalarFieldEnum = {
  id: 'id',
  transactionId: 'transactionId',
  customerId: 'customerId',
  addressId: 'addressId',
  items: 'items',
  couponId: 'couponId',
  couponCode: 'couponCode',
  subtotal: 'subtotal',
  shippingCost: 'shippingCost',
  discount: 'discount',
  total: 'total',
  status: 'status',
  paymentMethod: 'paymentMethod',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip',
  shippingChargeId: 'shippingChargeId'
};

exports.Prisma.PaymentTransactionScalarFieldEnum = {
  id: 'id',
  orderId: 'orderId',
  transactionId: 'transactionId',
  gateway: 'gateway',
  amount: 'amount',
  currency: 'currency',
  status: 'status',
  metadata: 'metadata',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip'
};

exports.Prisma.WishlistScalarFieldEnum = {
  id: 'id',
  userId: 'userId',
  productId: 'productId',
  created_at: 'created_at',
  updated_at: 'updated_at'
};

exports.Prisma.BannerScalarFieldEnum = {
  id: 'id',
  title: 'title',
  subtitle: 'subtitle',
  image: 'image',
  link: 'link',
  type: 'type',
  sequence_no: 'sequence_no',
  is_active: 'is_active',
  start_date: 'start_date',
  end_date: 'end_date',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip',
  company_id: 'company_id'
};

exports.Prisma.SpecialOfferScalarFieldEnum = {
  id: 'id',
  title: 'title',
  subtitle: 'subtitle',
  discount: 'discount',
  start_date: 'start_date',
  end_date: 'end_date',
  is_active: 'is_active',
  image: 'image',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip',
  company_id: 'company_id'
};

exports.Prisma.CouponScalarFieldEnum = {
  id: 'id',
  code: 'code',
  description: 'description',
  discount_type: 'discount_type',
  discount_amount: 'discount_amount',
  minimum_purchase: 'minimum_purchase',
  maximum_discount: 'maximum_discount',
  start_date: 'start_date',
  end_date: 'end_date',
  usage_limit: 'usage_limit',
  used_count: 'used_count',
  is_active: 'is_active',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip',
  company_id: 'company_id'
};

exports.Prisma.ShippingChargeScalarFieldEnum = {
  id: 'id',
  name: 'name',
  description: 'description',
  amount: 'amount',
  is_active: 'is_active',
  is_default: 'is_default',
  min_amount: 'min_amount',
  max_amount: 'max_amount',
  created_at: 'created_at',
  created_by: 'created_by',
  created_ip: 'created_ip',
  updated_at: 'updated_at',
  updated_by: 'updated_by',
  updated_ip: 'updated_ip',
  company_id: 'company_id'
};

exports.Prisma.SortOrder = {
  asc: 'asc',
  desc: 'desc'
};

exports.Prisma.JsonNullValueInput = {
  JsonNull: Prisma.JsonNull
};

exports.Prisma.NullableJsonNullValueInput = {
  DbNull: Prisma.DbNull,
  JsonNull: Prisma.JsonNull
};

exports.Prisma.JsonNullValueFilter = {
  DbNull: Prisma.DbNull,
  JsonNull: Prisma.JsonNull,
  AnyNull: Prisma.AnyNull
};

exports.Prisma.NullsOrder = {
  first: 'first',
  last: 'last'
};
exports.OrderStatus = exports.$Enums.OrderStatus = {
  PENDING: 'PENDING',
  PROCESSING: 'PROCESSING',
  SHIPPED: 'SHIPPED',
  DELIVERED: 'DELIVERED',
  CANCELLED: 'CANCELLED',
  RETURNED: 'RETURNED'
};

exports.PaymentStatus = exports.$Enums.PaymentStatus = {
  PENDING: 'PENDING',
  PAID: 'PAID',
  FAILED: 'FAILED',
  REFUNDED: 'REFUNDED'
};

exports.MovementType = exports.$Enums.MovementType = {
  PURCHASE: 'PURCHASE',
  SALE: 'SALE',
  RETURN: 'RETURN',
  ADJUSTMENT: 'ADJUSTMENT',
  DAMAGE: 'DAMAGE'
};

exports.Prisma.ModelName = {
  ApplicationLog: 'ApplicationLog',
  AuditLog: 'AuditLog',
  Company: 'Company',
  CompanyAdditionalInfo: 'CompanyAdditionalInfo',
  User: 'User',
  RefreshToken: 'RefreshToken',
  SecurityRule: 'SecurityRule',
  SecurityRuleWiseMenuPermission: 'SecurityRuleWiseMenuPermission',
  SecurityGroup: 'SecurityGroup',
  SecurityGroupRule: 'SecurityGroupRule',
  UserGroup: 'UserGroup',
  Menu: 'Menu',
  Product: 'Product',
  Category: 'Category',
  Subcategory: 'Subcategory',
  Brand: 'Brand',
  ProductAttribute: 'ProductAttribute',
  ProductVariant: 'ProductVariant',
  Seller: 'Seller',
  Review: 'Review',
  Customer: 'Customer',
  CustomerRefreshToken: 'CustomerRefreshToken',
  Order: 'Order',
  OrderItem: 'OrderItem',
  StockMovement: 'StockMovement',
  UserSettings: 'UserSettings',
  CustomerAddress: 'CustomerAddress',
  PendingOrder: 'PendingOrder',
  PaymentTransaction: 'PaymentTransaction',
  Wishlist: 'Wishlist',
  Banner: 'Banner',
  SpecialOffer: 'SpecialOffer',
  Coupon: 'Coupon',
  ShippingCharge: 'ShippingCharge'
};

/**
 * This is a stub Prisma Client that will error at runtime if called.
 */
class PrismaClient {
  constructor() {
    return new Proxy(this, {
      get(target, prop) {
        let message
        const runtime = getRuntime()
        if (runtime.isEdge) {
          message = `PrismaClient is not configured to run in ${runtime.prettyName}. In order to run Prisma Client on edge runtime, either:
- Use Prisma Accelerate: https://pris.ly/d/accelerate
- Use Driver Adapters: https://pris.ly/d/driver-adapters
`;
        } else {
          message = 'PrismaClient is unable to run in this browser environment, or has been bundled for the browser (running in `' + runtime.prettyName + '`).'
        }
        
        message += `
If this is unexpected, please open an issue: https://pris.ly/prisma-prisma-bug-report`

        throw new Error(message)
      }
    })
  }
}

exports.PrismaClient = PrismaClient

Object.assign(exports, Prisma)
